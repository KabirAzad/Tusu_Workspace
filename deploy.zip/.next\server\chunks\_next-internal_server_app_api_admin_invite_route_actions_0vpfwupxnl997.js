module.exports=[98639,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_invite_route_actions_0vpfwupxnl997.js.map