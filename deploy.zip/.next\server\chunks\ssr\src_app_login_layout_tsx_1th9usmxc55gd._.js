module.exports=[67357,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)(b.Fragment,{children:a})},"metadata",0,{title:"Sign In"}])},49384,function(a){a.n(a.i(67357))}];

//# sourceMappingURL=src_app_login_layout_tsx_1th9usmxc55gd._.js.map