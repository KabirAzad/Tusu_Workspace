var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dm/get-or-create/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_10_31hh8-53y-._.js")
R.c("server/chunks/_17qm_jum23mft._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_dm_get-or-create_route_actions_16ztv7f2d4dl3.js")
R.m(73892)
module.exports=R.m(73892).exports
