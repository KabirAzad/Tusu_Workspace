var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/invite/route.js")
R.c("server/chunks/[externals]__0xp-w031ecr12._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/[root-of-the-server]__1vxqhis8u0z6z._.js")
R.c("server/chunks/_17qm_jum23mft._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_invite_route_actions_0vpfwupxnl997.js")
R.m(6603)
module.exports=R.m(6603).exports
