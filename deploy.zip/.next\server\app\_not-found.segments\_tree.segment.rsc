:HL["/_next/static/chunks/2431wa4yhi739.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"GW5YgJvxuQ2p44tbqpos3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
