var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/members/[id]/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_02b45z_4x9m2_._.js")
R.c("server/chunks/_17qm_jum23mft._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_members_[id]_route_actions_1ztexeatyj-kq.js")
R.m(64815)
module.exports=R.m(64815).exports
