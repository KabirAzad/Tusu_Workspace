globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/GW5YgJvxuQ2p44tbqpos3/_buildManifest.js",
    "static/GW5YgJvxuQ2p44tbqpos3/_ssgManifest.js",
    "static/GW5YgJvxuQ2p44tbqpos3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0om590q-tq0l9.js",
    "static/chunks/0s2cptn1mmf6r.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/1xqw6oj1vq819.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/chat/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/dashboard/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/members/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/messages/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/profile/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/tasks/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/team-tasks/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1xqw6oj1vq819.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
