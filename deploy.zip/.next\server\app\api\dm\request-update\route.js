var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dm/request-update/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_1dxus7-hf8e_7._.js")
R.c("server/chunks/_17qm_jum23mft._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_dm_request-update_route_actions_16wet39-u2vc6.js")
R.m(9199)
module.exports=R.m(9199).exports
