module.exports=[18791,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_team-tasks_page_actions_0o4tcn46tm5_3.js.map