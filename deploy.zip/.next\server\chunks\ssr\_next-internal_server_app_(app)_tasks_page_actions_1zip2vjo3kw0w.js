module.exports=[83414,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_tasks_page_actions_1zip2vjo3kw0w.js.map